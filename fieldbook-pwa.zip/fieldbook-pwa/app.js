const today=new Date().toISOString().slice(0,10);
['c-date','d-date','s-date','p-date'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=today;});

function switchTab(t){
  ['calc','data','struct','pipe'].forEach(p=>{
    document.getElementById('page-'+p).classList.toggle('active',p===t);
    document.getElementById('tab-'+p).classList.toggle('active',p===t);
  });
  if(t==='data')syncJobHeader();
}

function syncJobHeader(){
  ['job','weather','temp','inst','instid','crew'].forEach(k=>{
    const c=document.getElementById('c-'+k),d=document.getElementById('d-'+k);
    if(c&&d&&!d.value&&c.value)d.value=c.value;
  });
  const cd=document.getElementById('c-date'),dd=document.getElementById('d-date');
  if(cd&&dd&&!dd.value&&cd.value)dd.value=cd.value;
}

function gv(id){return parseFloat(document.getElementById(id).value);}
function fmt(n,d=3){return(isNaN(n)||n===null)?'—':n.toFixed(d);}
function showToast(m){const t=document.getElementById('toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2000);}
function cpResult(vid,bid){
  const v=document.getElementById(vid).textContent;
  if(v==='—')return;
  const clean=v.replace('%','').replace('°','').split(' ')[0];
  navigator.clipboard.writeText(clean).catch(()=>{});
  const b=document.getElementById(bid);b.classList.add('flash');setTimeout(()=>b.classList.remove('flash'),600);
  showToast('Copied: '+clean);
}

// ── Calculator ──
function calcHI(){
  const hi=gv('bm-elev')+gv('bs-read');
  document.getElementById('hi-val').textContent=isNaN(hi)?'—':hi.toFixed(3);
  calcElev();
}
function calcElev(){
  const hiTxt=document.getElementById('hi-val').textContent;
  const hi=parseFloat(hiTxt),fs=gv('fs-read'),e=hi-fs;
  document.getElementById('elev-val').textContent=(isNaN(e)||hiTxt==='—')?'—':e.toFixed(3);
}
function calcTBM(){const v=gv('bm-known')+gv('tbm-bs')-gv('tbm-fs');document.getElementById('tbm-val').textContent=isNaN(v)?'—':v.toFixed(3);}
function calcDist(){const v=gv('st-k')*(gv('st-u')-gv('st-l'));document.getElementById('dist-val').textContent=isNaN(v)?'—':v.toFixed(3);}
function calcSlope(){
  const rise=gv('s-rise'),run=gv('s-run');
  if(!isNaN(rise)&&!isNaN(run)&&run!==0){
    document.getElementById('spct').textContent=(rise/run*100).toFixed(2)+'%';
    document.getElementById('sang').textContent=(Math.atan(rise/run)*180/Math.PI).toFixed(3)+'°';
    document.getElementById('srat').textContent='1:'+(run/Math.abs(rise)).toFixed(1);
  } else {
    ['spct','sang','srat'].forEach(id=>document.getElementById(id).textContent='—');
  }
}
function calcCF(){
  const design=gv('s-design'),actual=gv('s-actual');
  const b=document.getElementById('cf-badge'),v=document.getElementById('cf-val');
  if(!isNaN(design)&&!isNaN(actual)){
    const diff=actual-design;
    if(diff>0.001){b.className='badge badge-cut';b.textContent='CUT';v.textContent=diff.toFixed(3)+' ft';}
    else if(diff<-0.001){b.className='badge badge-fill';b.textContent='FILL';v.textContent=Math.abs(diff).toFixed(3)+' ft';}
    else{b.className='badge badge-grade';b.textContent='ON GRADE';v.textContent='0.000 ft';}
  } else {b.className='';b.textContent='';v.textContent='—';}
}

// ── Field Data ──
let ptId=1,bmId=1;
function mkInp(val='',cls=''){const td=document.createElement('td');const i=document.createElement('input');i.type='text';i.value=val;if(cls)i.className=cls;td.appendChild(i);return td;}
function mkSel(opts,val=''){const td=document.createElement('td');const s=document.createElement('select');opts.forEach(o=>{const op=document.createElement('option');op.value=o;op.textContent=o;s.appendChild(op);});s.value=val;td.appendChild(s);return td;}
function mkDel(fn){const td=document.createElement('td');const b=document.createElement('button');b.className='del-btn';b.innerHTML='✕';b.onclick=fn;td.appendChild(b);return td;}
function mkElevCell(){const td=document.createElement('td');td.className='elev-auto empty';td.textContent='—';return td;}
function updateRowElev(tr){
  const cells=tr.querySelectorAll('td');
  const hi=parseFloat(cells[1].querySelector('input').value);
  const fs=parseFloat(cells[3].querySelector('input').value);
  const et=cells[4];
  if(!isNaN(hi)&&!isNaN(fs)){const e=(hi-fs).toFixed(3);et.textContent=e;et.className='elev-auto';updateRowCF(tr,parseFloat(e));}
  else{et.textContent='—';et.className='elev-auto empty';updateRowCF(tr,NaN);}
}
function updateRowCF(tr,elev){
  const cells=tr.querySelectorAll('td');
  const di=cells[7].querySelector('input');
  const cfTd=cells[8];
  if(!di)return;
  const design=parseFloat(di.value);
  let badge=cfTd.querySelector('.cf-badge-row');
  let valEl=cfTd.querySelector('.cf-val-row');
  if(!badge){badge=document.createElement('span');badge.className='badge cf-badge-row';valEl=document.createElement('span');valEl.className='cf-val-row';valEl.style.cssText='font-family:Menlo,monospace;font-size:11px';cfTd.appendChild(badge);cfTd.appendChild(valEl);}
  if(!isNaN(elev)&&!isNaN(design)){
    const diff=elev-design;
    if(diff>0.001){badge.className='badge badge-cut cf-badge-row';badge.textContent='C';valEl.textContent=diff.toFixed(3);}
    else if(diff<-0.001){badge.className='badge badge-fill cf-badge-row';badge.textContent='F';valEl.textContent=Math.abs(diff).toFixed(3);}
    else{badge.className='badge badge-grade cf-badge-row';badge.textContent='G';valEl.textContent='0.000';}
  } else {badge.className='badge cf-badge-row';badge.textContent='';valEl.textContent='';}
}
function addPt(){
  const tr=document.createElement('tr');
  const numTd=document.createElement('td');numTd.textContent=ptId++;numTd.style.cssText='text-align:center;color:var(--gray-4)';
  tr.appendChild(numTd);
  const hiTd=mkInp('','mono'),bsTd=mkInp('','mono'),fsTd=mkInp('','mono');
  tr.appendChild(hiTd);tr.appendChild(bsTd);tr.appendChild(fsTd);
  const et=mkElevCell();tr.appendChild(et);
  tr.appendChild(mkInp('','mono'));tr.appendChild(mkInp('','mono'));
  const dTd=mkInp('','mono');tr.appendChild(dTd);
  const cfTd=document.createElement('td');cfTd.className='cf-td';tr.appendChild(cfTd);
  tr.appendChild(mkInp(''));tr.appendChild(mkDel(()=>tr.remove()));
  hiTd.querySelector('input').addEventListener('input',()=>updateRowElev(tr));
  fsTd.querySelector('input').addEventListener('input',()=>updateRowElev(tr));
  dTd.querySelector('input').addEventListener('input',()=>{const cells=tr.querySelectorAll('td');updateRowCF(tr,parseFloat(cells[4].textContent));});
  document.getElementById('pt-body').appendChild(tr);
}
function addBM(type='BM'){
  const tr=document.createElement('tr');
  const id=(type==='TBM'?'TBM-':'BM-')+bmId++;
  tr.appendChild(mkInp(id));tr.appendChild(mkInp(''));tr.appendChild(mkInp('','mono'));
  tr.appendChild(mkSel(['BM','TBM'],type));
  tr.appendChild(mkInp(document.getElementById('d-inst')?.value||''));
  tr.appendChild(mkInp(document.getElementById('d-date')?.value||today));
  tr.appendChild(mkInp(''));tr.appendChild(mkDel(()=>tr.remove()));
  document.getElementById('bm-body').appendChild(tr);
}
function addTBM(){addBM('TBM');}

function tableToCSV(tbl){
  let csv='';
  for(const row of tbl.rows){
    const cols=[];
    for(const cell of row.cells){
      const inp=cell.querySelector('input,select');
      let v='';
      if(inp){v=inp.value;}
      else{
        const badges=cell.querySelectorAll('.badge,.cf-badge-row');
        const vals=cell.querySelectorAll('.cf-val-row');
        if(badges.length){v=(badges[0].textContent||'')+' '+(vals[0]?vals[0].textContent:'');}
        else{v=cell.textContent;}
      }
      cols.push('"'+v.trim().replace(/"/g,'""')+'"');
    }
    csv+=cols.join(',')+'\n';
  }
  return csv;
}
function getJobMeta(){
  return{
    j:document.getElementById('d-job')?.value||document.getElementById('c-job')?.value||'',
    d:document.getElementById('d-date')?.value||today,
    w:document.getElementById('d-weather')?.value||'',
    tp:document.getElementById('d-temp')?.value||'',
    ins:document.getElementById('d-inst')?.value||'',
    insid:document.getElementById('d-instid')?.value||'',
    cr:document.getElementById('d-crew')?.value||''
  };
}
function exportCSV(){
  const m=getJobMeta();
  let csv='EXCAVATION FIELD BOOK\n';
  csv+=`Job:,"${m.j}",Date:,"${m.d}"\n`;
  csv+=`Weather:,"${m.w}",Temp:,"${m.tp}°F"\n`;
  csv+=`Instrument:,"${m.ins}",Serial:,"${m.insid}",Crew lead:,"${m.cr}"\n\n`;
  csv+='BENCHMARKS\n'+tableToCSV(document.getElementById('bm-table'));
  csv+='\nSURVEY POINTS\n'+tableToCSV(document.getElementById('pt-table'));
  const blob=new Blob([csv],{type:'text/csv'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);
  a.download='field-book-'+m.d+'.csv';a.click();
  showToast('CSV downloaded');
}

// ── Structure page ──
let invertCount=0,topType='cone';
function sCalcHI(){const hi=gv('s-bm')+gv('s-bs');document.getElementById('s-hi-val').textContent=isNaN(hi)?'—':hi.toFixed(3);sCalcElev();}
function sCalcElev(){const hiTxt=document.getElementById('s-hi-val').textContent;const hi=parseFloat(hiTxt),fs=gv('s-fs'),e=hi-fs;document.getElementById('s-elev-val').textContent=(isNaN(e)||hiTxt==='—')?'—':e.toFixed(3);}
function sToggleShape(){const sq=document.getElementById('struct-shape').value==='square';document.getElementById('s-width-label').textContent=sq?'Width (in)':'Diameter (in)';document.getElementById('s-length-field').style.display=sq?'':'none';}
function setTopType(t){topType=t;document.querySelectorAll('.top-tog button').forEach(b=>b.classList.toggle('active',b.dataset.type===t));sRender();}

function addInvert(dir='IN',size='',mat='RCP',htBase=''){
  if(invertCount>=5)return;
  invertCount++;
  const id='inv-'+invertCount;
  const div=document.createElement('div');div.className='inv-grid';div.id=id;
  const inStyle='height:36px;padding:0 5px;border:1px solid var(--border);border-radius:var(--radius);background:var(--gray-1);color:var(--gray-6);font-size:12px;font-family:Menlo,monospace;width:100%';
  const selStyle='height:36px;padding:0 4px;border:1px solid var(--border);border-radius:var(--radius);background:var(--gray-1);color:var(--gray-6);font-size:12px;width:100%';
  div.innerHTML=`<select onchange="sRender()" style="${selStyle}"><option value="IN" ${dir==='IN'?'selected':''}>IN</option><option value="OUT" ${dir==='OUT'?'selected':''}>OUT</option></select>
    <input type="number" step="1" placeholder="12" value="${size}" style="${inStyle}" oninput="sRender()">
    <select onchange="sRender()" style="${selStyle} font-size:11px"><option ${mat==='RCP'?'selected':''}>RCP</option><option ${mat==='PVC'?'selected':''}>PVC</option><option ${mat==='HDPE'?'selected':''}>HDPE</option><option ${mat==='CMP'?'selected':''}>CMP</option><option ${mat==='DIP'?'selected':''}>DIP</option><option>Other</option></select>
    <input type="number" step="0.25" placeholder="0" value="${htBase}" style="${inStyle}" oninput="sRender()">
    <div class="inv-elev empty" id="elev-${id}">—</div>
    <button class="del-btn" onclick="removeInvert('${id}')">✕</button>`;
  document.getElementById('invert-list').appendChild(div);
  if(invertCount>=5)document.getElementById('add-inv-btn').style.display='none';
  sRender();
}
function removeInvert(id){document.getElementById(id).remove();invertCount--;document.getElementById('add-inv-btn').style.display='';sRender();}

function buildSections(){
  const n=parseInt(document.getElementById('section-count').value)||1;
  const list=document.getElementById('section-list');
  const eH=[...list.querySelectorAll('.sec-h')].map(i=>i.value);
  const eL=[...list.querySelectorAll('.sec-l')].map(i=>i.value);
  list.innerHTML='';
  const inStyle='height:36px;padding:0 8px;border:1px solid var(--border);border-radius:var(--radius);background:var(--gray-1);color:var(--gray-6);font-size:13px;font-family:Menlo,monospace;width:100%';
  const txStyle='height:36px;padding:0 8px;border:1px solid var(--border);border-radius:var(--radius);background:var(--gray-1);color:var(--gray-6);font-size:13px;width:100%';
  for(let i=0;i<n;i++){
    const isTop=(i===n-1);
    const div=document.createElement('div');
    div.className='sec-row '+(isTop?'sec-top':'sec-normal');
    const def=i===0?'Base':isTop&&n>1?'Cone/Top':'Riser '+i;
    const lv=eL[i]||def,hv=eH[i]||'';
    if(isTop){
      div.innerHTML=`<input type="text" class="sec-l" placeholder="${def}" value="${lv}" style="${txStyle}" oninput="sRender()">
        <input type="number" step="0.01" inputmode="decimal" class="sec-h" placeholder="2.00" value="${hv}" style="${inStyle}" oninput="sRender()">
        <div class="top-tog"><button data-type="cone" class="${topType==='cone'?'active':''}" onclick="setTopType('cone')">▲ Cone</button><button data-type="flat" class="${topType==='flat'?'active':''}" onclick="setTopType('flat')">▬ Flat</button></div>`;
    } else {
      div.innerHTML=`<input type="text" class="sec-l" placeholder="${def}" value="${lv}" style="${txStyle}" oninput="sRender()">
        <input type="number" step="0.01" inputmode="decimal" class="sec-h" placeholder="4.00" value="${hv}" style="${inStyle}" oninput="sRender()">`;
    }
    list.appendChild(div);
  }
  sRender();
}

function sGetInverts(exc){
  const rows=document.getElementById('invert-list').children;
  const result=[];
  for(const row of rows){
    const sels=row.querySelectorAll('select');
    const inps=row.querySelectorAll('input');
    const htBase=inps[1]?parseFloat(inps[1].value):NaN;
    const id=row.id;
    let elev=NaN,auto=false;
    if(!isNaN(htBase)&&!isNaN(exc)){elev=exc+(htBase/12);auto=true;}
    const cell=document.getElementById('elev-'+id);
    if(cell){
      if(!isNaN(elev)){cell.textContent=elev.toFixed(3);cell.className='inv-elev'+(elev<exc?' inv-warn':'');}
      else{cell.textContent='enter bottom elev';cell.className='inv-elev empty';}
    }
    result.push({dir:sels[0]?.value||'IN',size:inps[0]?.value||'',mat:sels[1]?.value||'',htBase,elev,auto,id});
  }
  return result;
}

function addERow(tbody,label,val,cls='',indent=false){
  const tr=document.createElement('tr');if(cls)tr.className=cls;
  tr.innerHTML=`<td style="${indent?'padding-left:14px':''}">${label}</td><td>${fmt(val)}</td>`;
  tbody.appendChild(tr);
}
function addDivRow(tbody){const tr=document.createElement('tr');tr.className='div-row';tr.innerHTML='<td colspan="2"><hr></td>';tbody.appendChild(tr);}

function sRender(){
  const rt=document.getElementById('record-type').value;
  const banner=document.getElementById('mode-banner');
  const sid=document.getElementById('struct-id').value;
  const stype=document.getElementById('struct-type').value;
  const ref=document.getElementById('sheet-ref').value;
  if(rt){banner.style.display='flex';banner.className='mode-banner '+(rt==='plan'?'mode-plan':'mode-asbuilt');document.getElementById('mode-banner-text').textContent=(rt==='plan'?'Plan grades':'As built')+(stype?' — '+stype:'')+(sid?' '+sid:'')+(ref?' (Sheet '+ref+')':'');}
  else banner.style.display='none';

  const exc=gv('exc-elev');
  const inverts=sGetInverts(exc);
  const sections=[...document.getElementById('section-list').children].map(row=>({
    label:row.querySelector('.sec-l')?.value||row.querySelector('.sec-l')?.placeholder||'Section',
    h:parseFloat(row.querySelector('.sec-h')?.value)
  }));
  const tbody=document.getElementById('elev-body');tbody.innerHTML='';
  addERow(tbody,'Excavation / bottom of structure',exc,'hl-warn');
  addDivRow(tbody);
  inverts.forEach((inv,i)=>{
    const badge=`<span class="badge badge-${inv.dir==='IN'?'in':'out'}">${inv.dir}</span>`;
    const htNote=!isNaN(inv.htBase)?` <span style="font-size:10px;color:var(--gray-4)">${inv.htBase}" from base</span>`:'';
    const autoNote=inv.auto?`<span class="auto-tag">auto</span>`:'';
    const bad=!isNaN(exc)&&!isNaN(inv.elev)&&inv.elev<exc;
    addERow(tbody,`${badge} Inv ${i+1}${inv.size?' — '+inv.size+'"':''} ${inv.mat}${htNote} ${autoNote}${bad?' <span style="color:var(--red);font-size:10px">⚠ below base</span>':''}`,inv.elev,'inv-row'+(bad?' inv-warn':''),true);
  });
  if(inverts.length)addDivRow(tbody);
  let runElev=exc;
  const n=sections.length;
  sections.forEach((sec,i)=>{
    const isTop=(i===n-1);
    const top=isNaN(runElev)||isNaN(sec.h)?NaN:runElev+sec.h;
    const tb=isTop?`<span class="top-badge ${topType==='cone'?'top-cone':'top-flat'}">${topType==='cone'?'cone':'flat top'}</span>`:'';
    addERow(tbody,`Top of ${sec.label} ${tb} (+${isNaN(sec.h)?'?':sec.h.toFixed(2)} ft)`,top,'sub',true);
    if(!isNaN(top))runElev=top;
  });
  const topOS=isNaN(runElev)?NaN:runElev;
  if(sections.length)addDivRow(tbody);
  addERow(tbody,`Top of structure (${topType==='cone'?'cone top':'flat top'})`,topOS,'hl-accent');
  const coverH=gv('cover-h'),fg=gv('finish-grade');
  const fgOut=document.getElementById('s-fg-output'),cfOut=document.getElementById('s-cf-output');
  if(!isNaN(topOS)&&!isNaN(coverH)){
    addDivRow(tbody);addERow(tbody,'Bottom of cover / frame',topOS,'');addERow(tbody,'Top of cover',topOS+coverH,'hl-success');
    if(!isNaN(fg)){
      const diff=(topOS+coverH)-fg,abs=Math.abs(diff).toFixed(3);
      let bcls,lbl,col;
      if(diff>0.005){bcls='badge-cut';lbl='CUT';col='var(--teal)';}
      else if(diff<-0.005){bcls='badge-fill';lbl='FILL';col='var(--amber)';}
      else{bcls='badge-grade';lbl='ON GRADE';col='var(--blue)';}
      cfOut.innerHTML=`<div class="cf-result"><div><span class="badge ${bcls}" style="display:inline-block;margin-bottom:4px">${lbl}</span><div class="cf-result-label">${diff>0.005?`Cover ${abs} ft above finish grade`:diff<-0.005?`Cover ${abs} ft below finish grade`:'Cover at finish grade'}</div></div><div class="cf-result-val" style="color:${col}">${diff>0.005?'-':diff<-0.005?'+':'±'}${abs} ft</div></div>`;
      fgOut.innerHTML='';
    } else {fgOut.innerHTML='<p style="font-size:12px;color:var(--gray-4);margin-top:6px">Enter finish grade elevation to see adjustment.</p>';cfOut.innerHTML='';}
  } else {fgOut.innerHTML='<p style="font-size:12px;color:var(--gray-4);margin-top:6px">Enter structure and cover height above.</p>';cfOut.innerHTML='';}
}

// ── Pipe Run ──
const SPECS={RCP:{w:s=>s<=12?1.5:s<=24?2:s<=36?2.5:3},PVC:{w:s=>s<=4?0.23:s<=8?0.28:s<=12?0.37:0.42},HDPE:{w:s=>+(s*0.06).toFixed(2)},CMP:{w:()=>0.064},DIP:{w:s=>s<=12?0.38:s<=24?0.43:0.5},VCP:{w:s=>s<=12?0.75:1}};
const MIN_S={RCP:{6:0.5,8:0.4,10:0.35,12:0.28,15:0.22,18:0.18,21:0.15,24:0.12,30:0.10,36:0.08},PVC:{4:0.28,6:0.14,8:0.11,10:0.09,12:0.08},HDPE:{6:0.14,8:0.11,12:0.08},CMP:{12:0.5,15:0.43,18:0.36,24:0.29},DIP:{6:0.14,8:0.11,12:0.08},VCP:{6:0.35,8:0.22,10:0.16,12:0.13}};
let pStations=[],stnIdCtr=1;
function pCalcHI(){const hi=gv('p-bm')+gv('p-bs');document.getElementById('p-hi-val').textContent=isNaN(hi)?'—':hi.toFixed(3);pCalcElev();}
function pCalcElev(){const hiTxt=document.getElementById('p-hi-val').textContent;const hi=parseFloat(hiTxt),fs=gv('p-fs'),e=hi-fs;document.getElementById('p-elev-val').textContent=(isNaN(e)||hiTxt==='—')?'—':e.toFixed(3);}
function getMinSlope(){const t=document.getElementById('pipe-type').value,s=parseFloat(document.getElementById('pipe-size').value);if(!t||!s||!MIN_S[t])return null;const keys=Object.keys(MIN_S[t]).map(Number).sort((a,b)=>a-b);for(const k of keys){if(s<=k)return MIN_S[t][k];}return null;}
function onPipeChange(){const t=document.getElementById('pipe-type').value,s=parseFloat(document.getElementById('pipe-size').value);if(t&&s&&SPECS[t]){const w=SPECS[t].w(s);document.getElementById('pipe-id').value=s.toFixed(2);document.getElementById('pipe-od').value=(s+2*w).toFixed(2);}pRender();}
function getPipeSlope(){const up=gv('inv-up'),dn=gv('inv-dn'),len=gv('run-len');if(isNaN(up)||isNaN(dn)||isNaN(len)||len<=0)return null;return{up,dn,len,slope:(up-dn)/len,fall:up-dn};}
function invAtDist(d,sr){return sr?sr.up-sr.slope*d:NaN;}
function calcGrades(inv){
  const idV=gv('pipe-id'),odV=gv('pipe-od'),sb=gv('sand-below')||4,sa=gv('sand-above')||12;
  if(isNaN(inv))return{inv:NaN,botP:NaN,botE:NaN,topP:NaN,topS:NaN};
  const odFt=!isNaN(odV)?odV/12:null,idFt=!isNaN(idV)?idV/12:null;
  const botP=odFt&&idFt?inv-(odFt-idFt)/2:NaN;
  const botE=!isNaN(botP)?botP-sb/12:NaN;
  const topP=odFt&&idFt?inv+(odFt+idFt)/2:NaN;
  const topS=!isNaN(topP)?topP+sa/12:NaN;
  return{inv,botP,botE,topP,topS};
}
function toggleNewExtra(){
  const t=document.getElementById('new-type').value;
  const ex=document.getElementById('new-extra');
  const fit=document.getElementById('new-fitting');
  const cut=document.getElementById('new-cut-label');
  if(t==='fitting'){ex.style.display='';fit.style.display='';cut.style.display='none';}
  else if(t==='cut'){ex.style.display='';fit.style.display='none';cut.style.display='';}
  else{ex.style.display='none';}
}
function addStation(){
  const dist=parseFloat(document.getElementById('new-dist').value);
  const type=document.getElementById('new-type').value;
  const label=document.getElementById('new-label').value||'';
  const runLen=gv('run-len');
  if(isNaN(dist)||dist<0){showToast('Enter a valid distance.');return;}
  if(!isNaN(runLen)&&dist>runLen){showToast('Distance exceeds run length.');return;}
  let detail='';
  if(type==='fitting')detail=document.getElementById('new-fitting').value;
  else if(type==='cut')detail=document.getElementById('new-cut-label').value||'Cut pipe';
  pStations.push({id:stnIdCtr++,dist,type,detail,label,overrideInv:null});
  pStations.sort((a,b)=>a.dist-b.dist);
  document.getElementById('new-dist').value='';
  document.getElementById('new-label').value='';
  buildStationList();pRender();
}
function removeStation(id){pStations=pStations.filter(s=>s.id!==id);buildStationList();pRender();}
function setOverride(id){const val=parseFloat(document.getElementById('ov-inp-'+id).value);const stn=pStations.find(s=>s.id===id);if(stn&&!isNaN(val)){stn.overrideInv=val;buildStationList();pRender();}}
function clearOverride(id){const stn=pStations.find(s=>s.id===id);if(stn){stn.overrideInv=null;buildStationList();pRender();}}
function buildStationList(){
  const sl=document.getElementById('station-list');sl.innerHTML='';
  const sr=getPipeSlope();
  const inpStyle='height:30px;padding:0 8px;border:1px solid var(--border);border-radius:var(--radius);background:#fff;color:var(--gray-6);font-size:12px;font-family:Menlo,monospace;width:100%';
  pStations.forEach(stn=>{
    const autoInv=sr?invAtDist(stn.dist,sr):NaN;
    const useInv=stn.overrideInv!==null?stn.overrideInv:autoInv;
    const g=calcGrades(useInv);
    const isCustom=stn.type==='cut'||stn.type==='fitting';
    const detailStr=stn.detail?` — ${stn.detail}`:'';
    const labelStr=stn.label||stn.type+detailStr;
    const ov=stn.overrideInv!==null;
    const div=document.createElement('div');div.className='stn-item';
    div.innerHTML=`<div class="stn-hdr"><div style="display:flex;align-items:center;gap:6px"><span class="stn-num${isCustom?' custom':''}">${stn.dist} ft</span><span style="font-size:12px;color:var(--gray-5)">${labelStr}</span>${ov?'<span style="font-size:10px;color:var(--amber);background:var(--amber-light);padding:1px 6px;border-radius:4px;font-weight:500">override</span>':''}</div><button class="stn-del" onclick="removeStation(${stn.id})">✕</button></div>
      <div class="stn-grades">
        <div class="grade-row"><span class="grade-lbl">Invert (flow line)</span><span class="grade-val accent">${fmt(g.inv)}</span></div>
        <div class="grade-row"><span class="grade-lbl">Bottom of pipe</span><span class="grade-val">${fmt(g.botP)}</span></div>
        <div class="grade-row"><span class="grade-lbl">Bottom of excavation</span><span class="grade-val">${fmt(g.botE)}</span></div>
        <div class="grade-row"><span class="grade-lbl">Top of pipe</span><span class="grade-val">${fmt(g.topP)}</span></div>
        <div class="grade-row"><span class="grade-lbl">Top of sand</span><span class="grade-val">${fmt(g.topS)}</span></div>
      </div>
      <div class="ov-row"><input class="ov-inp" id="ov-inp-${stn.id}" type="number" step="0.001" inputmode="decimal" placeholder="${isNaN(autoInv)?'auto':autoInv.toFixed(3)} (auto)" value="${ov?stn.overrideInv.toFixed(3):''}">
      ${ov?`<button class="ov-btn clear" onclick="clearOverride(${stn.id})">↺ Reset</button>`:`<button class="ov-btn" onclick="setOverride(${stn.id})">Override</button>`}</div>`;
    sl.appendChild(div);
  });
}
function getStartLabel(){const t=document.getElementById('start-type').value;if(t==='fi')return 'Field inlet (start)';if(t==='outlet')return 'Outlet (start)';return document.getElementById('start-custom').value||'Start';}
function getEndLabel(){const t=document.getElementById('end-type').value;if(t==='fi')return 'Field inlet (end)';if(t==='outlet')return 'Outlet (end)';return document.getElementById('end-custom').value||'End';}
function pRender(){
  document.getElementById('start-custom-wrap').style.display=document.getElementById('start-type').value==='custom'?'':'none';
  document.getElementById('end-custom-wrap').style.display=document.getElementById('end-type').value==='custom'?'':'none';
  const idV=gv('pipe-id'),odV=gv('pipe-od');
  const wc=document.getElementById('wall-thick');
  if(!isNaN(idV)&&!isNaN(odV)){wc.textContent=((odV-idV)/2).toFixed(3)+'"';wc.className='dim-auto';}
  else{wc.textContent='enter ID and OD';wc.className='dim-auto empty';}
  const sr=getPipeSlope();
  const up=gv('inv-up'),dn=gv('inv-dn');
  const sd=document.getElementById('start-elev-disp'),ed=document.getElementById('end-elev-disp');
  if(!isNaN(up)){sd.textContent=up.toFixed(3)+' ft';sd.className='ep-elev';}else{sd.textContent='enter upstream invert above';sd.className='ep-elev empty';}
  if(!isNaN(dn)){ed.textContent=dn.toFixed(3)+' ft';ed.className='ep-elev';}else{ed.textContent='enter downstream invert above';ed.className='ep-elev empty';}
  const fall=sr?sr.fall:NaN,slope=sr?sr.slope:NaN,slopePct=!isNaN(slope)?slope*100:NaN;
  document.getElementById('res-fall').textContent=isNaN(fall)?'—':fall.toFixed(3)+' ft';
  document.getElementById('res-slope-pct').textContent=isNaN(slopePct)?'—':slopePct.toFixed(4)+'%';
  document.getElementById('res-rat').textContent=(!isNaN(slope)&&slope!==0)?(1/Math.abs(slope)).toFixed(1)+':1':'—';
  document.getElementById('res-dir').textContent=isNaN(fall)?'—':fall>0.001?'▼ US → DS':fall<-0.001?'▲ Reverse grade':'→ Level';
  const be=document.getElementById('res-slope-badge');
  if(!isNaN(slopePct)){const ms=getMinSlope();let cls,lbl;if(slopePct<0){cls='badge-low';lbl='⚠ Reverse grade';}else if(ms&&slopePct<ms){cls='badge-warn';lbl=`⚠ ${slopePct.toFixed(4)}% below min ${ms}%`;}else if(slopePct>10){cls='badge-warn';lbl=`${slopePct.toFixed(4)}% — steep`;}else{cls='badge-ok';lbl=`✓ ${slopePct.toFixed(4)}%`;}be.innerHTML=`<span class="badge ${cls}">${lbl}</span>`;}else be.innerHTML='<span class="res-val">—</span>';
  const mn=document.getElementById('min-grade-note'),ms=getMinSlope();
  if(ms&&!isNaN(slopePct)){mn.style.display='block';const sz=document.getElementById('pipe-size').value,tp=document.getElementById('pipe-type').value;if(slopePct>=ms){mn.className='min-note min-ok';mn.textContent=`✓ Meets minimum self-cleaning grade of ${ms}% for ${sz}" ${tp}`;}else{mn.className='min-note min-warn';mn.textContent=`⚠ Below minimum ${ms}% for ${sz}" ${tp}. Sediment may accumulate.`;}}else mn.style.display='none';
  buildStationList();
  buildGradeTable(sr,up,dn);
}
function buildGradeTable(sr,up,dn){
  const body=document.getElementById('gt-body');body.innerHTML='';
  const runLen=gv('run-len');
  if(!sr||isNaN(up)||isNaN(dn)){const tr=document.createElement('tr');tr.innerHTML='<td colspan="6" style="text-align:center;color:var(--gray-4);padding:14px;font-size:12px">Enter upstream invert, downstream invert, and run length above.</td>';body.appendChild(tr);return;}
  const rows=[];
  rows.push({dist:0,label:getStartLabel(),inv:up,isEnd:true,isCustom:false});
  const segLen=gv('seg-len')||10;
  let d=segLen;while(d<runLen-0.01){const k=+(d.toFixed(3));if(!pStations.find(s=>Math.abs(s.dist-k)<0.01))rows.push({dist:k,label:`${k} ft`,inv:invAtDist(k,sr),isEnd:false,isCustom:false});d+=segLen;}
  rows.push({dist:runLen,label:getEndLabel(),inv:dn,isEnd:true,isCustom:false});
  pStations.forEach(stn=>{const useInv=stn.overrideInv!==null?stn.overrideInv:invAtDist(stn.dist,sr);const detailStr=stn.detail?` — ${stn.detail}`:'';rows.push({dist:stn.dist,label:(stn.label||(stn.type+detailStr))+` (${stn.dist} ft)`,inv:useInv,isEnd:false,isCustom:true});});
  rows.sort((a,b)=>a.dist-b.dist);
  rows.forEach(row=>{
    const g=calcGrades(row.inv);
    const tr=document.createElement('tr');
    if(row.isEnd)tr.className='gt-ep';else if(row.isCustom)tr.className='gt-cust';
    tr.innerHTML=`<td>${row.label}</td><td>${fmt(g.inv)}</td><td>${fmt(g.botP)}</td><td>${fmt(g.botE)}</td><td>${fmt(g.topP)}</td><td>${fmt(g.topS)}</td>`;
    body.appendChild(tr);
  });
}

// Init
addBM();addPt();addPt();
addInvert('IN','12','RCP','');addInvert('OUT','12','RCP','');
buildSections();sRender();pRender();
